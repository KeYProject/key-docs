Inspired by the integer overflow bug in java.util.Arrays#binarySearch(...).

http://bugs.java.com/bugdatabase/view_bug.do?bug_id=5045582
http://googleresearch.blogspot.de/2006/06/extra-extra-read-all-about-it-nearly.html