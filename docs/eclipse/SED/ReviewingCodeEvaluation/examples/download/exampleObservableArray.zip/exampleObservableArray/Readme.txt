Inspired by Book  
Effective Java (2nd Edition) (The Java Series)
2 
Prentice Hall PTR Upper Saddle River, NJ, USA �2008 
ISBN:0321356683 9780321356680

Listing:
- ObservableSet example at page 265