

package java.lang;


public final class Class {

}
