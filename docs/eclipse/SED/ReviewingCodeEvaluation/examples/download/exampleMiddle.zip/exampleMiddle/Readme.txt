Inspired by Book  
Why Programs Fail: A Guide to Systematic Debugging
Morgan Kaufmann Publishers Inc. San Francisco, CA, USA �2005 
ISBN:1558608664

Example:
- 11.1: The middle program returns the middle number of three (page 255)