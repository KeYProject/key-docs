Inspired by Book  
Code Complete, Second Edition
Microsoft Press Redmond, WA, USA �2004 
ISBN:0735619670 9780735619678

Listings:
- Java Example of a Clumsy Way to Determine an Insurance Rate, page 415
- Visual Basic Example of a Stair-Step Table Lookup, page 427