Example shown at workshop 'JML: Advancing Specification Language Methodologies'.
http://www.lorentzcenter.nl/lc/web/2015/677/info.php3?wsid=677&venue=Snellius