Simplified version of FMCO 2006 Submission:
"Verifying Object-Oriented Programs with KeY: A Tutorial"
http://www.key-project.org/fmco06/