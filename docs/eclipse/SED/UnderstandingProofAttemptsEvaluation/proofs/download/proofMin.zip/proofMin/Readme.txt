Simplified version of lab exercise used during lecture 
'Formale Grundlagen der Informatik 3' (FGdI3) at TU Darmstadt.